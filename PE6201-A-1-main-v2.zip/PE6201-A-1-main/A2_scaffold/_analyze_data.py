import json, sys
sys.stdout.reconfigure(encoding='utf-8')
key = json.load(open('../A2_reference_data/expected_outcomes_B.json', encoding='utf-8'))
print(f'Total labeled cases: {len(key)}')
negatives = [r for r in key if r.get('expected_decision') in ('escalate', 'request_document', 'request_information')]
print(f'Negative cases: {len(negatives)}')
bookings = [r for r in key if r.get('expected_decision') == 'book']
print(f'Book cases (positive/ordinary): {len(bookings)}')
print()
print('Expected decision distribution:')
from collections import Counter
c = Counter(r['expected_decision'] for r in key)
for k, v in c.items():
    print(f'  {k:<22}: {v}')
print()
print('Trigger distribution for negatives:')
trig = Counter(r.get('trigger', '(no trigger)') for r in negatives)
for k, v in trig.items():
    print(f'  {k:<32}: {v}')
print()
print('Case IDs + decision + family:')
for r in key:
    print(f'  {r["case_id"]:<12} {r["expected_decision"]:<22} {r.get("family", "")}')
