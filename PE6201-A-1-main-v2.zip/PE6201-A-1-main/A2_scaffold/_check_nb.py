import json, sys
sys.stdout.reconfigure(encoding='utf-8')
nb = json.load(open("A2_Sequential_Live_Run.ipynb", encoding="utf-8"))
print("OK JSON format valid")
print(f"Total cells: {len(nb['cells'])}")
types = {}
for c in nb["cells"]:
    t = c["cell_type"]
    types[t] = types.get(t, 0) + 1
print(f"  Markdown cells: {types.get('markdown', 0)}")
print(f"  Code cells:     {types.get('code', 0)}")
print()
print("Cell list (in order):")
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] == "markdown":
        src = "".join(c["source"])
        first_line = src.split("\n")[0][:70]
        print(f"  [{i:>2}] MD  | {first_line}")
    else:
        src = "".join(c["source"])
        first_line = src.strip().split("\n")[0][:70] if src.strip() else "(empty)"
        print(f"  [{i:>2}] CODE| {first_line}")
