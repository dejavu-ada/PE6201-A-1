import sys
sys.stdout.reconfigure(encoding='utf-8')
import run_d2c_compare
sys.exit(run_d2c_compare.main(['run_d2c_compare.py', '--csv']))
