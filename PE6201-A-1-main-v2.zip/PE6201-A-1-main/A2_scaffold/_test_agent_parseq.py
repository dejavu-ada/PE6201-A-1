import sys
sys.stdout.reconfigure(encoding='utf-8')
import config, agent

print('=== REF-5602 parallel (default) ===')
r_par = agent.run_case('REF-5602', verbose=False, parallel_tools=True)
print('  turns=%s, tools=%s, exec_mode=%s' % (r_par['turns'], len(r_par['tool_trace']), r_par['execution_mode']))

print()
print('=== REF-5602 sequential ===')
r_seq = agent.run_case('REF-5602', verbose=True, parallel_tools=False)
print('  turns=%s, tools=%s, exec_mode=%s' % (r_seq['turns'], len(r_seq['tool_trace']), r_seq['execution_mode']))

from harness import load_key, code_check
key = load_key('B')
exp = key['REF-5602']
print()
par_pass, _ = code_check(r_par, exp)
seq_pass, _ = code_check(r_seq, exp)
print('Code check -  PAR:', 'OK PASS' if par_pass else 'XX FAIL')
print('Code check -  SEQ:', 'OK PASS' if seq_pass else 'XX FAIL')
