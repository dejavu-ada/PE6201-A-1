#!/usr/bin/env python3
"""
PE6201 · A2 — D3(b) GUARDRAIL TESTS
====================================================================
    python3 run_guardrails.py              run all 10 cases on scripted
    python3 run_guardrails.py GR_DEDUP     only run tests whose id includes DE
    python3 run_guardrails.py --verbose    print every per-test assertion

Ten DETERMINISTIC guardrail cases. No model, no key, no network.
Tests: step cap | budget ceiling | de-duplication ×2 | autonomy gate ×2
       | 3 hostile-free-text prompt-injection negatives | 1 no-fire
       regression control.

Each case writes PASS/FAIL. 10/10 PASS is the submission standard.
Results also go to outputs/guardrail_results.json so your trace is
reproducible without re-running.
====================================================================
"""
import csv
import importlib
import json
import os
import sys

import config
import guardrails as G

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "outputs")
os.makedirs(OUT_DIR, exist_ok=True)


def _apply_config_overrides(over):
    """Temporarily (within one test) override module-level config values.

    We mutate the actual config module because the guardrails object reads
    from config at construction time. Caller MUST call _restore afterwards
    or the fixture leaks across tests.
    """
    snapshot = {}
    for k, v in (over or {}).items():
        snapshot[k] = getattr(config, k, None)
        setattr(config, k, v)
    return snapshot


def _restore_config(snapshot):
    for k, v in snapshot.items():
        setattr(config, k, v)


# ---------------------------------------------------------------------
# individual test drivers. These exist because not every guardrail test
# is a full case run. Some (DEDUP tests) exercise the guards class
# directly — that's the whole point of a pure-code guardrail layer.
# ---------------------------------------------------------------------

def _run_case_through_agent(test, verbose=False):
    """Helper: run a real case_id through run_case with optional overrides
    and optional approve() returning False."""
    from agent import run_case

    over = test.get("config_override") or {}
    snap = _apply_config_overrides(over)
    try:
        approve = (lambda a, p: bool(test.get("approve_returns", True))) \
            if test.get("approve_returns") is not None else None
        cid = test["case_id"]
        record = run_case(cid, approve=approve, verbose=False)
    finally:
        _restore_config(snap)
    return record


def _check_assert(test, ctx):
    """ctx = {"record":..} | {"exc":..} depending on test kind. Returns
    (passed, messages)."""
    a = test["assert"]
    msg = []
    passed = True

    def _ok(cond, text):
        nonlocal passed
        if not cond:
            passed = False
            msg.append("FAIL " + text)
        else:
            msg.append(" ok  " + text)

    rec = ctx.get("record") or {}
    exc = ctx.get("exc")

    if "stopped_by" in a:
        _ok(rec.get("stopped_by") == a["stopped_by"],
             "stopped_by=%r (got %r)" % (a["stopped_by"], rec.get("stopped_by")))

    if "decision" in a:
        _ok(rec.get("decision") == a["decision"],
             "decision=%r (got %r)" % (a["decision"], rec.get("decision")))

    if "trigger" in a:
        _ok(rec.get("trigger") == a["trigger"],
             "trigger=%r (got %r)" % (a["trigger"], rec.get("trigger")))

    if "fired_includes" in a:
        fired_names = [g["guardrail"] for g in rec.get("guardrails_fired", [])]
        _ok(a["fired_includes"] in fired_names,
             "guardrails_fired contains %r (got %r)"
             % (a["fired_includes"], fired_names))

    if "must_not_fire" in a:
        fired_names = [g["guardrail"] for g in rec.get("guardrails_fired", [])]
        bad = [x for x in a["must_not_fire"] if x in fired_names]
        _ok(not bad, "guardrails %r must NOT fire (got %r)" % (bad, fired_names))

    if a.get("booked_is_none_or_absent"):
        booked = rec.get("booked")
        _ok(booked in (None, {}) or not booked,
             "booked must be empty (got %r)" % (booked,))

    if a.get("stopped_by_is_none"):
        _ok(rec.get("stopped_by") is None,
             "stopped_by must be None (got %r)" % (rec.get("stopped_by"),))

    if a.get("code_check_pass"):
        from harness import load_key, code_check
        exp = load_key().get(test["case_id"])
        if exp is None:
            _ok(False, "code_check: no expected key for case_id %r"
                 % test["case_id"])
        else:
            ok, f = code_check(rec, exp)
            _ok(ok, "code_check PASS (fails=%r)" % (f,))

    if "raises" in a:
        if a["raises"] == "GuardrailStop":
            is_gs = (exc is not None) and isinstance(exc, G.GuardrailStop)
            _ok(is_gs, "raises GuardrailStop (got %r)"
                 % (type(exc).__name__ if exc else None))
            if is_gs and "reason" in a:
                _ok(exc.reason == a["reason"],
                     "exc.reason=%r (got %r)" % (a["reason"], exc.reason))

    return passed, msg


# ---------------------------------------------------------------------
# direct guard tests (DEDUP tests — pure module, no agent)
# ---------------------------------------------------------------------

def _pure_dedup_test01():
    """GR_DEDUP_01: double identical get_referral call must raise."""
    guards = G.Guardrails(8, 99999, "act")
    args = {"referral_id": "REF-5590"}
    guards.check_duplicate("get_referral", args)   # first one OK
    try:
        guards.check_duplicate("get_referral", dict(args))  # second → raise
        return {"record": {"guardrails_fired": guards.fired}, "exc": None}
    except G.GuardrailStop as e:
        return {"record": {"guardrails_fired": guards.fired}, "exc": e}


def _pure_dedup_test02():
    """GR_DEDUP_02: two identical book_slot calls."""
    guards = G.Guardrails(8, 99999, "act")
    args = {"clinic": "OPH-C2", "date": "2026-10-14", "time": "11:00",
            "patient_id": "P-1180", "referral_id": "REF-5602"}
    guards.check_duplicate("book_slot", args)
    try:
        guards.check_duplicate("book_slot", dict(args))
        return {"record": {"guardrails_fired": guards.fired}, "exc": None}
    except G.GuardrailStop as e:
        return {"record": {"guardrails_fired": guards.fired}, "exc": e}


# ---------------------------------------------------------------------
# Step-cap & budget need synthetic backends. To keep things simple we
# still use the agent but rely on the real case runs + guards being
# invoked: for step cap we build a tiny synthetic Guards check to
# trigger the behaviour, which is what the guardrail code actually
# guarantees.
# ---------------------------------------------------------------------

def _pure_stepcap_test01():
    """GR_STEPCAP_01: turns 7 passes, turn 9 must raise step_cap."""
    guards = G.Guardrails(8, 99999, "act")
    try:
        for t in range(1, 10):
            guards.check_turns(t)
        return {"record": {"guardrails_fired": guards.fired}, "exc": None}
    except G.GuardrailStop as e:
        return {"record": {"guardrails_fired": guards.fired,
                           "turns_at_stop": t}, "exc": e}


def _pure_budget_test01():
    """GR_BUDGET_01: 399 passes, 500 must raise budget_ceiling."""
    guards = G.Guardrails(999, 400, "act")
    try:
        for tok in [100, 200, 399, 500]:
            guards.check_budget(tok)
        return {"record": {"guardrails_fired": guards.fired}, "exc": None}
    except G.GuardrailStop as e:
        return {"record": {"guardrails_fired": guards.fired,
                           "tokens_at_stop": tok}, "exc": e}


DRIVERS = {
    "GR_STEPCAP_01": _pure_stepcap_test01,
    "GR_BUDGET_01": _pure_budget_test01,
    "GR_DEDUP_01": _pure_dedup_test01,
    "GR_DEDUP_02": _pure_dedup_test02,
}


# ---------------------------------------------------------------------
def main(argv):
    sys.stdout.reconfigure(encoding='utf-8') if hasattr(sys.stdout,
                                                         "reconfigure") else None

    print()
    print(config.summary())
    print("data:", config.data_root())

    filter_text = argv[1] if len(argv) > 1 and not argv[1].startswith("-") else ""
    flags = {a for a in argv[1:] if a.startswith("-")}
    verbose = "--verbose" in flags

    with open(os.path.join(HERE, "guardrail_cases.json"),
              encoding="utf-8") as fh:
        manifest = json.load(fh)

    plan = [t for t in manifest["cases"]
            if filter_text.upper() in t["id"].upper()]
    print()
    print("D3(b) guardrail test suite: %d/%d cases match filter %r"
          % (len(plan), len(manifest["cases"]), filter_text or "(all)"))
    print()

    results = []
    for i, test in enumerate(plan, 1):
        driver = DRIVERS.get(test["id"])
        if driver:
            ctx = driver()
        else:
            ctx = {"record": _run_case_through_agent(test, verbose=verbose),
                   "exc": None}

        passed, messages = _check_assert(test, ctx)
        mark = "PASS" if passed else "FAIL"
        print("  [%02d] %-30s [%s]  %s"
              % (i, test["id"], mark, test["target"]))
        if verbose or not passed:
            for m in messages:
                print("        " + m)
        results.append({
            "id": test["id"],
            "target": test["target"],
            "description": test.get("description", ""),
            "passed": passed,
            "messages": messages,
            "record_summary": {
                "stopped_by": (ctx.get("record") or {}).get("stopped_by"),
                "decision": (ctx.get("record") or {}).get("decision"),
                "trigger": (ctx.get("record") or {}).get("trigger"),
                "fired_names": [g["guardrail"] for g in
                                (ctx.get("record") or {}).get("guardrails_fired", [])],
                "exc_reason": ctx["exc"].reason if ctx.get("exc") else None,
            }
        })

    total = len(results)
    passed = sum(1 for r in results if r["passed"])
    print()
    print("=" * 68)
    print("  GUARDRAIL RESULTS: %d / %d PASS   (%.0f%%)"
          % (passed, total, 100.0 * passed / total if total else 0))
    print("=" * 68)

    failed = [r for r in results if not r["passed"]]
    if failed:
        print("  FAILING TESTS:")
        for r in failed:
            print("    - %s (%s)" % (r["id"], r["target"]))
            for m in r["messages"]:
                if m.startswith("FAIL"):
                    print("        %s" % m)
    else:
        print("  All guardrail tests passed.")
    print()

    out_path = os.path.join(OUT_DIR, "guardrail_results.json")
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump({
            "config": config.summary(),
            "manifest_meta": manifest.get("meta", {}),
            "summary": {"total": total, "passed": passed,
                        "pass_rate": passed / total if total else 0},
            "results": results,
        }, fh, indent=2, default=str)
    print("  wrote", out_path)

    csv_path = os.path.join(OUT_DIR, "guardrail_results.csv")
    with open(csv_path, "w", encoding="utf-8", newline="") as fh:
        fieldnames = ["id", "target", "description", "passed",
                      "stopped_by", "decision", "trigger",
                      "fired_names", "exc_reason", "messages"]
        w = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in results:
            rs = r.get("record_summary", {})
            w.writerow({
                "id": r.get("id"),
                "target": r.get("target"),
                "description": r.get("description", ""),
                "passed": r.get("passed"),
                "stopped_by": rs.get("stopped_by"),
                "decision": rs.get("decision"),
                "trigger": rs.get("trigger"),
                "fired_names": " | ".join(rs.get("fired_names", []) or []),
                "exc_reason": rs.get("exc_reason"),
                "messages": " || ".join(r.get("messages", []) or []),
            })
    print("  wrote", csv_path)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
