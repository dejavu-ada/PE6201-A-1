import json, sys, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, 'A2_scaffold')

exp_data = json.load(open('A2_reference_data/expected_outcomes_B.json', encoding='utf-8'))
if isinstance(exp_data, list):
    exp = {}
    for row in exp_data:
        cid = row.get('referral_id') or row.get('case_id')
        if cid:
            exp[cid] = row
else:
    exp = dict(exp_data)

print('TOTAL expected_outcomes_B entries:', len(exp))

book_n = sum(1 for v in exp.values() if v.get('decision')=='book')
neg_n = len(exp) - book_n
print('  BOOK (ordinary):', book_n)
print('  NEGATIVE (not book):', neg_n)
for d in ['escalate','request_information','request_document','approve_in_principle','reject']:
    n = sum(1 for v in exp.values() if v.get('decision')==d)
    if n: print('   ', d, n)

fam_neg = {}
for k,v in exp.items():
    if v.get('decision') != 'book':
        fam = v.get('family','?')
        fam_neg.setdefault(fam, []).append(k)
print('Negative families:')
for f, ks in fam_neg.items(): print(' ', f, '->', len(ks), ks[:3], '...' if len(ks)>3 else '')

import importlib.util
spec = importlib.util.spec_from_file_location('b', 'A2_scaffold/backends.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
print()
print('SCRIPTED entries in backends.py:', len(b.SCRIPTS))

missing_expected = [k for k in exp if k not in b.SCRIPTS]
extra = [k for k in b.SCRIPTS if k not in exp]
print('  expected_outcomes but NOT in scripted SCRIPTS:', len(missing_expected))
if missing_expected: print('    sample first 20:', missing_expected[:20])
print('  scripted but NOT in expected:', len(extra), extra if extra else '')

scripted_neg = 0
for k in b.SCRIPTS:
    if k in exp and exp[k].get('decision') != 'book':
        scripted_neg += 1
print('  Scripted negatives (non-book):', scripted_neg)

# Trials count: ordinary *1 + negative *3
trials = 0
for cid in b.SCRIPTS:
    if cid not in exp: continue
    trials += 3 if exp[cid].get('decision')!='book' else 1
print('  Expected total trials:', trials)

print()
print('--- guardrail manifest ---')
gm = json.load(open('A2_scaffold/guardrail_cases.json', encoding='utf-8'))
cases = gm.get('cases', []) if isinstance(gm, dict) else gm
print('Guardrail test cases:', len(cases))
hostile = sum(1 for c in cases if 'hostile' in (c.get('target','')+c.get('id','')).lower())
print('  hostile-tagged:', hostile)

print()
print('--- poka-yoke & tools ---')
import tools
t = importlib.import_module('tools')
print('tools available:', list(t.DESCRIPTOR_SETS.get('v2', {}).keys()))
pk = getattr(t, 'POKA_YOKE_COUNT', None)
print('poka-yoke counter:', pk)
