import sys, os, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, 'A2_scaffold')

from pprint import pprint
from collections import Counter

exp_data = json.load(open('A2_reference_data/expected_outcomes_B.json', encoding='utf-8'))
exp = {}
if isinstance(exp_data, list):
    for r in exp_data:
        cid = r.get('referral_id') or r.get('case_id')
        if cid: exp[cid] = r
else:
    exp = dict(exp_data)

print('First 3 entries structure:')
for cid in list(exp.keys())[:3]:
    print('\n -', cid)
    pprint(exp[cid])
print()

dec_counter = Counter()
for v in exp.values():
    dec_counter.update([str(v.get('decision'))])
print('Unique decisions (raw values):')
print('  ', dict(dec_counter))

import harness
from harness import _is_negative
negs = sum(1 for v in exp.values() if _is_negative(v))
books = sum(1 for v in exp.values() if not _is_negative(v))
print('\nBy harness._is_negative -> negatives:', negs, 'ordinary (not _is_negative):', books)

neg_samples = []; book_samples = []
for k,v in exp.items():
    if _is_negative(v): neg_samples.append(k)
    else: book_samples.append(k)
print('First 10 ordinary/booking samples:', book_samples[:10])
print('First 10 negative samples:', neg_samples[:10])

print('\n--- Poka-yoke scan tools.py ---')
import tools
print('Descriptor keys (v2):', list(tools.DESCRIPTOR_SETS.get('v2', {}).keys()))
sample_tool = 'get_clinic_slots'
d = tools.DESCRIPTOR_SETS['v2'].get(sample_tool, {})
print(f'\n{sample_tool} v2 descriptor contents:')
for k in d: print('  ', k, '->', str(d[k])[:120])

import inspect
print('\n--- Tools functions with poka-yoke signatures ---')
for name in dir(tools):
    fn = getattr(tools, name, None)
    if callable(fn) and hasattr(fn, '__module__') and fn.__module__ == 'tools' and not name.startswith('_'):
        print(' -', name, inspect.signature(fn) if hasattr(inspect,'signature') else '')

import guardrails
print('\n--- Guardrails ---')
print('Guardrails methods (public):')
for n in dir(guardrails.Guardrails):
    if not n.startswith('_'): print('  -', n)

print('\n--- Agent loop info ---')
import agent
import inspect as ins
src = ins.getsource(agent.run_case)
# count while/for loops
import re
whiles = len(re.findall(r'\bwhile\b', src))
print('run_case while-loops:', whiles)
print('has PARALLEL_TOOLS branch:', 'parallel_tools' in src)
print('uses LangChain/Graph?:', 'langchain' in src.lower() or 'langgraph' in src.lower())

import prompt
print('\n--- System prompt ---')
sp = prompt.build_system_prompt()
print('system prompt length:', len(sp), 'chars')
print('Has PARALLEL_TOOLS dependency rules?',
      any(w in sp for w in ['dependency', 'independent', 'parallel', 'cannot parallel', 'same turn']))
